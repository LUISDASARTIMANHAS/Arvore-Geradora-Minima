# Arvore-Geradora-Minima
Árvore Geradora: uma árvore T, subgrafo
de G, que contém todos os nós de G.

• Uma árvore geradora cuja a soma dos
pesos de seus arcos seja menor do que
em qualquer outra situação é chamada de
árvore geradora mínima.

## Prim Algoritmo
1. Seleciona um nó
2. Identifica o nó conectado mais próximo e
repetir o passo até todos estiverem
conectados

## Kruskal Algoritmo
1. Seleciona as arestas de menor peso, sem
formar ciclos ate que não exista mais a
possibilidade
